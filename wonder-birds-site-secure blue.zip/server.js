const express=require('express'),crypto=require('crypto'),fs=require('fs'),path=require('path');
const app=express();app.set('trust proxy',1);app.use(express.json({limit:'20kb'}));
const SECRET=process.env.SESSION_SECRET||crypto.randomBytes(32).toString('hex');
const LV={community:1,growth:2,strategic:3};
const users=()=>{try{return JSON.parse(process.env.USERS_JSON||fs.readFileSync('users.json','utf8'))}catch(e){return{}}};
const mac=b=>crypto.createHmac('sha256',SECRET).update(b).digest('base64url');
const sign=p=>{const b=Buffer.from(JSON.stringify(p)).toString('base64url');return b+'.'+mac(b)};
function read(t){if(!t)return null;const[b,s]=t.split('.');if(!s)return null;const e=mac(b);if(s.length!==e.length||!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(e)))return null;const p=JSON.parse(Buffer.from(b,'base64url'));return p.exp>Date.now()?p:null}
const sess=r=>{const m=(r.headers.cookie||'').match(/wb=([^;]+)/);return m?read(m[1]):null};
const tries={};
app.post('/api/login',(req,res)=>{
  const ip=req.ip,n=tries[ip]=(tries[ip]||{c:0,t:Date.now()});if(Date.now()-n.t>9e5){n.c=0;n.t=Date.now()}
  if(n.c>=8)return res.status(429).json({error:'Too many attempts. Try again in 15 minutes.'});
  const e=String(req.body.email||'').toLowerCase().trim(),u=users()[e];let ok=false;
  if(u){const h=crypto.scryptSync(String(req.body.password||''),u.salt,64);ok=crypto.timingSafeEqual(h,Buffer.from(u.hash,'hex'))}
  if(!ok){n.c++;return res.status(401).json({error:'Email or password incorrect.'})}
  const tok=sign({e,tier:u.tier,exp:Date.now()+8*36e5});
  res.setHeader('Set-Cookie','wb='+tok+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'+(process.env.NODE_ENV==='production'||process.env.RENDER?'; Secure':''));
  res.json({tier:u.tier});
});
app.post('/api/logout',(q,res)=>{res.setHeader('Set-Cookie','wb=; HttpOnly; Path=/; Max-Age=0');res.json({ok:true})});
app.get('/api/content',(req,res)=>{
  const s=sess(req);if(!s)return res.status(401).json({error:'login'});
  const out=Object.keys(LV).filter(t=>LV[t]<=LV[s.tier]).map(t=>fs.readFileSync(path.join(__dirname,'private',t+'.html'),'utf8'));
  res.set('Cache-Control','no-store');res.json({tier:s.tier,html:out.join('')});
});
app.post('/api/lead',(req,res)=>{
  const b=req.body||{};if(!b.name||!b.contact)return res.status(400).json({error:'Name and contact required.'});
  const a=Number(b.amount)||0,k=b.kind;
  if(k==='preorder'&&a<400)return res.status(400).json({error:'Minimum R400.'});
  if(k==='invest'&&a<500)return res.status(400).json({error:'Minimum R500.'});
  const rec=JSON.stringify({at:new Date().toISOString(),...b}).slice(0,2000);
  console.log('LEAD '+rec);try{fs.appendFileSync(process.env.LEADS_FILE||'leads.jsonl',rec+'\n')}catch(e){}
  res.json({ok:true});
});
app.use(express.static(path.join(__dirname,'public')));
app.listen(process.env.PORT||3000,()=>console.log('Wonder Birds site up'));
