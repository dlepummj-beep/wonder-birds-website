// usage: node adduser.js email password community|growth|strategic
const crypto=require('crypto'),fs=require('fs');const[,,e,p,t]=process.argv;
if(!e||!p||!['community','growth','strategic'].includes(t)){console.log('usage: node adduser.js email password community|growth|strategic');process.exit(1)}
let u={};try{u=JSON.parse(fs.readFileSync('users.json','utf8'))}catch(x){}
const salt=crypto.randomBytes(16).toString('hex');
u[e.toLowerCase()]={salt,hash:crypto.scryptSync(p,salt,64).toString('hex'),tier:t};
fs.writeFileSync('users.json',JSON.stringify(u,null,1));
console.log('Saved. For Render, set USERS_JSON to:\n'+JSON.stringify(u));
